#include "il2cpp-config.h"

#include "icalls/mscorlib/System/__ComObject.h"

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
    mscorlib_System___ComObject * __ComObject::CreateRCW(Il2CppReflectionType * t)
    {
        NOT_IMPLEMENTED_ICALL(__ComObject::CreateRCW);
        return 0;
    }

    void __ComObject::ReleaseInterfaces(mscorlib_System___ComObject * thisPtr)
    {
        NOT_IMPLEMENTED_ICALL(__ComObject::ReleaseInterfaces);
    }

    intptr_t __ComObject::GetInterfaceInternal(mscorlib_System___ComObject * thisPtr, Il2CppReflectionType * t, bool throwException)
    {
        NOT_IMPLEMENTED_ICALL(__ComObject::GetInterfaceInternal);
        return intptr_t();
    }
} /* namespace System */
} /* namespace mscorlib */
} /* namespace icalls */
} /* namespace il2cpp */
