#pragma once
#if NET_4_0

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
    class LIBIL2CPP_CODEGEN_API TimeSpan
    {
    public:
        static bool LegacyFormatMode();
    };
} // namespace System
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
#endif
