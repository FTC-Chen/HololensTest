#if IL2CPP_DEBUGGER_ENABLED

#include "vm.h"

using namespace il2cpp::debugger;

#endif
