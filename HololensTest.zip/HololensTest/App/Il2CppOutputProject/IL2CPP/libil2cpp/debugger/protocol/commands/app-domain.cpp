#if IL2CPP_DEBUGGER_ENABLED

#include "app-domain.h"

using namespace il2cpp::debugger;

#endif
