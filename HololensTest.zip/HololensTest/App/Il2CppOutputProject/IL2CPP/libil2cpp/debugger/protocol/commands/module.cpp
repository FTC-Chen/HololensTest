#if IL2CPP_DEBUGGER_ENABLED

#include "module.h"

using namespace il2cpp::debugger;

#endif
